'use client'

import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Particles } from "react-tsparticles"
import { loadSlim } from "tsparticles-slim"
import { type Container } from 'tsparticles-engine'
import { Heart, Cake, PartyPopperIcon as Party, Gift, Stars } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function BirthdayGreeting() {
  const [currentSlide, setCurrentSlide] = useState(0)
  
  const particlesInit = useCallback(async (engine: any) => {
    await loadSlim(engine)
  }, [])

  const slides = [
    {
      title: "Happy Birthday Sneha! 🎉",
      content: "Happy Birthday to the most special part of my code! 👩‍💻",
      subtitle: "You're the best feature of my life's algorithm.",
      footer: "Wishing you endless happiness, just like an infinite loop of love! 💝"
    },
    {
      title: "Debug Your Special Day! 🎈",
      content: "May your day be free of bugs and full of joy!",
      subtitle: "Your happiness compiles successfully in my heart",
      footer: "Runtime: Forever & Ever ❤️"
    },
    {
      title: "System.out.println(\"Happy Birthday!\") 🎂",
      content: "You're not just any variable in my life",
      subtitle: "You're my constant source of happiness!",
      footer: "Return type: Infinite Joy 🌟"
    }
  ]

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-pink-200 to-pink-300 overflow-hidden">
      <Particles
        id="tsparticles"
        init={particlesInit}
        options={{
          particles: {
            color: { value: "#FFD700" },
            move: {
              direction: "none",
              enable: true,
              outModes: "out",
              random: true,
              speed: 2,
              straight: false
            },
            number: { value: 50 },
            opacity: { value: 0.5 },
            shape: { type: "star" },
            size: { value: 3 }
          }
        }}
        className="absolute inset-0"
      />
      
      <div className="relative z-10 container mx-auto px-4 py-8 min-h-screen flex flex-col items-center justify-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="text-center space-y-8"
          >
            <motion.h1 
              className="text-4xl md:text-6xl font-bold text-yellow-400 drop-shadow-lg"
              initial={{ scale: 0.5 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
            >
              {slides[currentSlide].title}
            </motion.h1>

            <motion.div
              className="space-y-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              <p className="text-2xl md:text-3xl text-white font-semibold text-shadow">
                {slides[currentSlide].content}
              </p>
              
              <p className="text-xl md:text-2xl text-pink-600 font-medium">
                {slides[currentSlide].subtitle}
              </p>

              <p className="text-lg md:text-xl text-white font-medium text-shadow">
                {slides[currentSlide].footer}
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              <Button
                onClick={nextSlide}
                className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-2 rounded-full text-lg font-semibold shadow-lg transition-transform hover:scale-105"
              >
                Next
              </Button>
            </motion.div>
          </motion.div>
        </AnimatePresence>

        <motion.div 
          className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          {slides.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full ${
                currentSlide === index ? 'bg-white' : 'bg-pink-300'
              }`}
            />
          ))}
        </motion.div>
      </div>
    </div>
  )
}

